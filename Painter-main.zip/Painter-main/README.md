# Painter
Painter from Ethiopia
